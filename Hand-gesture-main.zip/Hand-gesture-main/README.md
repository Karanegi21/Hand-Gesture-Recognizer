About the Project :-
HAND SIGN RECOGNISER is a Web Application that is a revolution in the space of communication for people who have problems in hearing and speaking.
We use the latest technology like Computer Vision to empower the specially abled to do our part for society



Steps to Run the app (for the first Time) :-
1. Clone the repository using - git clone "link" in cmd
2. Install the dependancies using npm install

Steps to Run the app (otherwise) :-
In the project directory, you can run:

### `npm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in your browser.
